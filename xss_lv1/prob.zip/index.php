if(isset($_POST['Sign'])){
	$comm = trim($_POST['comment']);							
	echo "입력한 값: ".$comm;
}